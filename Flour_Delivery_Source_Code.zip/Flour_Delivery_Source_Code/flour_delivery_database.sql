-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 07, 2024 at 07:04 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flour_delivery`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('sakshi', '1307'),
('abhinav', '0987'),
('sakshi', '1234'),
('sopan', '1234'),
('sopan', '12345'),
('aftab', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `buy`
--

CREATE TABLE `buy` (
  `Productid` int(50) NOT NULL,
  `quantity` varchar(30) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buy`
--

INSERT INTO `buy` (`Productid`, `quantity`, `price`) VALUES
(123, '25', 550),
(1, '3', 550),
(1, '50', 550),
(1, '25', 550),
(1, '25', 550),
(1, '25', 550),
(1, '25', 550),
(1, '10', 550),
(1, '1', 400),
(1, '--select the quantity--', 400),
(2, '1', 350),
(2, '--select the quantity--', 350),
(2, '--select the quantity--', 350),
(1, '--select the quantity--', 400),
(1, '--select the quantity--', 400),
(1, '--select the quantity--', 400),
(1, '5', 400),
(4, '1', 400),
(1, '1', 400),
(1, '1', 400),
(3, '1', 300),
(3, '1', 300),
(3, '1', 300),
(2, '1', 350),
(1, '5', 90),
(1, '5', 120),
(1, '--select the quantity--', 120),
(1, '--select the quantity--', 120);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `username` varchar(20) NOT NULL,
  `productid` int(20) NOT NULL,
  `price` int(20) NOT NULL,
  `quantity` int(20) NOT NULL,
  `amount` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`username`, `productid`, `price`, `quantity`, `amount`) VALUES
('sopan', 3, 300, 5, 1500),
('dnyaneshwar', 2, 350, 5, 1750),
('sopan', 2, 350, 1, 350),
('aftab', 3, 90, 10, 900),
('aftab', 4, 80, 10, 800),
('sopan', 4, 80, 25, 2000),
('aftab', 1, 120, 1, 120),
('aftab', 1, 120, 100, 12000),
('aftab', 2, 100, 50, 5000),
('', 1, 120, 5, 600),
('', 1, 120, 5, 600),
('aftab', 1, 60, 5, 300),
('sopan', 1, 60, 5, 300),
('sopan', 2, 50, 5, 250),
('sopan', 3, 70, 5, 350),
('sopan', 1, 60, 5, 300),
('sopan', 1, 60, 1, 60),
('sopan', 1, 60, 1, 60),
('sopan', 1, 60, 1, 60),
('sopan', 2, 50, 1, 50),
('sopan', 2, 50, 25, 1250),
('sopan', 1, 60, 1, 60),
('sopan', 1, 60, 1, 60),
('sopan', 1, 60, 1, 60),
('sopan', 2, 50, 5, 250),
('sopan', 1, 120, 5, 600),
('sopan', 2, 50, 5, 250),
('sopan', 2, 70, 5, 350),
('sopan', 3, 60, 5, 300),
('sopan', 4, 80, 5, 400),
('sopan', 2, 70, 5, 350),
('sopan', 2, 70, 5, 350);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `c_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`c_id`, `name`, `email`, `phone`, `message`) VALUES
(2, 'sopan', 'sopankawate99@gmail.com', '9307950164', 'no'),
(7, 'sopan', 'sopankawate99@gmail.com', '9307950164', 'no'),
(8, 'sopan', 'sopankawate99@gmail.com', '9307950164', 'no'),
(9, '', '', '', ''),
(10, '', '', '', ''),
(11, '', '', '', ''),
(12, '', '', '', ''),
(13, '', '', '', ''),
(14, '', '', '', ''),
(15, '', '', '', ''),
(16, '', '', '', ''),
(17, '', '', '', ''),
(19, 'sopan', 'sopankawate99@gmail.com', '9307950164', 'flour');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `Feedback` varchar(100) NOT NULL,
  `EmailId` varchar(50) NOT NULL,
  `Name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`Feedback`, `EmailId`, `Name`) VALUES
('aftab mulani', 'aftab@gmail.com', '\r\n\"Great app! Flour arrives fresh and on time. Easy ordering process. Happy customer!\"'),
('dnyneshwar dhotre', 'dnyneshwar@gmail.com', '\r\n\"Flour delivery app exceeded expectations! Quick, reliable service, top-notch flour quality. User-friendly interface made ordering a pleasure. Highly recommend for baking enthusiasts!\"'),
('sachin ughade', 'sachin@gmail.com', '\r\n\"Consistently reliable flour deliveries, convenient app interface. Appreciate the quality and variety. Makes baking a breeze! Highly recommended for home bakers.\"'),
('sopan kawate', 'sopan@gmail.com', '\"Efficient service, fresh flour, seamless experience. Appreciate timely deliveries and user-friendly interface. Keep up the great work!\"\r\n\r\n\r\n\r\n\"Efficient service, fresh flour, seamless experience. Ap');

-- --------------------------------------------------------

--
-- Table structure for table `orderdet`
--

CREATE TABLE `orderdet` (
  `ordno` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ordermst`
--

CREATE TABLE `ordermst` (
  `odt` varchar(20) NOT NULL,
  `ordno` int(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `amount` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pay`
--

CREATE TABLE `pay` (
  `p_id` int(11) NOT NULL,
  `card_holder` text NOT NULL,
  `cardno` text NOT NULL,
  `amount` text NOT NULL,
  `cvv` text NOT NULL,
  `expMM` text NOT NULL,
  `expYY` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pay`
--

INSERT INTO `pay` (`p_id`, `card_holder`, `cardno`, `amount`, `cvv`, `expMM`, `expYY`) VALUES
(3, 'dnyaneshwar', '45354254543', '300', '54', '54', '45'),
(4, '', '', '550', '', '', ''),
(5, '', '', '80', '', '', ''),
(6, 'dnyaneshwar', '34445', '80', '6889', '22', '22'),
(7, 'dnyaneshwar', '35325234545', '350', '353', '53', '35'),
(8, 'dnyaneshwar', '', '120', '', '', ''),
(9, 'sopan', '4649464', '120', '145', '23', '23'),
(10, 'sopan', '76565534', '120', '234', '02', '24'),
(11, 'sopan', '2432445', '120', '234', '2', '24'),
(12, '', '', '120', '', '', ''),
(13, 'sopan', '13455', '350', '233', '1', '24');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `odt` date NOT NULL,
  `username` varchar(20) NOT NULL,
  `mode` int(20) NOT NULL,
  `amount` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`odt`, `username`, `mode`, `amount`) VALUES
('0000-00-00', 'abhinav', 0, 5500),
('0000-00-00', 'abhinav', 0, 5500),
('0000-00-00', 'abhinav', 0, 5500),
('0000-00-00', 'abhinav', 0, 5500),
('0000-00-00', 'dnyaneshwar', 0, 1750),
('0000-00-00', 'aftab', 0, 600);

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE `receipt` (
  `Receiptdate` int(11) NOT NULL,
  `Receiptamount` int(11) NOT NULL,
  `Date` int(11) NOT NULL,
  `EmailId` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `Name` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `ContactNo` int(10) NOT NULL,
  `EmailId` varchar(50) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `securityques` varchar(1000) NOT NULL,
  `securityanswer` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`Name`, `Address`, `ContactNo`, `EmailId`, `Password`, `securityques`, `securityanswer`) VALUES
('aftab', 'pune', 2147483647, 'aftab@gmail.com', '123', 'In which city you born?', 'pune'),
('dnyaneshwar', 'satara', 2147483647, 'dnyneshwar@gmail.com', '123', 'What was the name of your favourite car/bike?', 'mercedes'),
('sachin', 'mumbai', 2147483647, 'sachin@gmail.com', '123', 'In which city you born?', 'pune'),
('shubham', 'pimpri', 2147483647, 'shubham@gmail.com', '123', 'In which city you born?', 'kolhapur'),
('sopan', 'pune', 2147483647, 'sopan@gmail.com', '123', '-------Select the question-------', '123');

-- --------------------------------------------------------

--
-- Table structure for table `uploadproduct`
--

CREATE TABLE `uploadproduct` (
  `productname` varchar(50) NOT NULL,
  `productid` int(20) NOT NULL,
  `price` int(20) NOT NULL,
  `image` varchar(10000) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `uploadproduct`
--

INSERT INTO `uploadproduct` (`productname`, `productid`, `price`, `image`, `description`) VALUES
('Wheat Flour', 1, 120, 'wheat.webp', 'According to some research, it may also be able to reduce obesity. Enhances immunity Black wheat flour contains more antioxidants than regular wheat, which maintains our antibodies and prevents the formation of free radicals. Furthermore, they protect against DNA damage and lipid peroxidation.'),
('Bajra Flour', 2, 70, 'Bajra flour.jpeg', ' Bajra flour, made from pearl millet, is a nutritious, gluten-free option used in Indian cuisine. It\'s rich in fiber, protein, and essential minerals, promoting digestion and overall health.'),
('Jowar Flour', 3, 60, 'jowar image.png', 'Jowar flour, made from sorghum, is a gluten-free and nutritious flour. It\'s high in fiber and protein, commonly used in Indian cuisine for making rotis and other dishes.'),
('Corn flour', 4, 80, 'Corn flour image.jpg', 'Corn flour, made from finely ground corn, is a versatile, gluten-free ingredient. It\'s used in baking, thickening soups, and making tortillas, providing a slightly sweet flavor and smooth texture.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`EmailId`);

--
-- Indexes for table `ordermst`
--
ALTER TABLE `ordermst`
  ADD PRIMARY KEY (`ordno`);

--
-- Indexes for table `pay`
--
ALTER TABLE `pay`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`EmailId`);

--
-- Indexes for table `uploadproduct`
--
ALTER TABLE `uploadproduct`
  ADD PRIMARY KEY (`productid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `ordermst`
--
ALTER TABLE `ordermst`
  MODIFY `ordno` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pay`
--
ALTER TABLE `pay`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `uploadproduct`
--
ALTER TABLE `uploadproduct`
  MODIFY `productid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5787;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
