<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <script src="jquery.js"></script>
  <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="header">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Flour Delivery</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
          <!-- <li><a href="guidance.php">Guidance</a></li> -->
          <li><a href="product.php">Buy Product</a></li>
        <!-- <li><a href="cropcare.php">Crop Care</a></li> -->
<li><a href="feedback.php">Feedback</a></li>
        </ul>
      </li>  
    </ul>
    <ul class="nav navbar-nav navbar-right">
         <li><a href="viewcart.php"><span class="glyphicon glyphicon-shopping-cart"></span></a></li>  
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
    </ul>
  </div>
</nav>