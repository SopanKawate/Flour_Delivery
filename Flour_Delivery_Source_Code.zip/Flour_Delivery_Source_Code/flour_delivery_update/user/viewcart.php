<html>
<head>
    <style>
        *{
            margin:auto auto;
            padding: auto auto;
        }
        .column{
           margin:auto auto;
           margin-left:400px;
           width:700px;
           color:black;
           font-size:18px;
           font-weight:700px;
        }
        .row{
            margin:auto auto;
            margin-left:400px;
            margin-top:10px;
            width:700px;
            color:black;
            font-size:18px;
            font-weight:700px;
        }
    </style>
</head>
</html>
<?php
session_start();
include("header.php");
?>

<div class="column">
    <h1 align=center>Your Cart</h1>
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th>Actions</th>
                    <th>Image</th>
                    <th>Productid</th>
                    <th>price</th>
                    <th>quantity</th>
                    <th>amount</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include("connection.php");
                $u = $_SESSION["username"];
                
                $q = "SELECT cart.productid, cart.price, cart.quantity, cart.amount, uploadproduct.image FROM cart INNER JOIN uploadproduct ON cart.productid = uploadproduct.productid WHERE cart.username='$u'";
                $rs = mysqli_query($cn, $q);
                // echo "<h2>result </h2> $rs";
                if (!$rs) {
                    printf("Error: %s\n", mysqli_error($cn));
                    exit();
                }

                while ($a = mysqli_fetch_array($rs)) {
                    extract($a);
                    echo "<tr>";
                    echo "<td><a href='del.php?uname=$u&productid=$productid'>DELETE</a></td>";
                    echo "<td><img src='images/$image' width='100' height='100'></td>";
                    echo "<td>$productid</td>";
                    echo "<td>$price Rs</td>";
                    echo "<td>$quantity kg</td>";
                    echo "<td>$amount Rs</td>";
                    echo "</tr>";
                }
                $total = 0;
                $q = "SELECT SUM(amount) FROM cart WHERE username='$u'";
                $rs = mysqli_query($cn, $q);
                if (!$rs) {
                    printf("Error: %s\n", mysqli_error($cn));
                    exit();
                }
                if ($a = mysqli_fetch_array($rs)) {
                    $total = $a[0];
                }
                echo "<tr><td></td><td></td><td></td><td></td><td></td><td><b>Total Amount</b></td><td><b>$total</b></td></tr>";
                mysqli_close($cn);
                ?>
            </tbody>
        </table>
        <br>
        <center><a class="btn btn-primary" href='payment.php?amount=<?php echo $total; ?>'>Confirm Order and Proceed to payment</a></center>
    </div>
</div>

<?php
include("footer.php");
?>