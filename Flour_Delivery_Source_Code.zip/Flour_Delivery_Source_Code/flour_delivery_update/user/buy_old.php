<!-- <html><head>
  
@import url('https://fonts.googleapis.com/css?family=Muli');

/*reset*/
* {
  margin: 0;
  padding: 0;
}

/*product info */

h1 {
  color: #ff6d39;
  font-family: "muli";
  font-weight: bold;
  font-size: 22px;
  margin-top: 21px;
  display: inline-block;
}

i.fa.fa-search {
  margin-left: 90px;
}

.product-name i {
  color: #ffffff;
  transition: 0.3s all ease;
  margin: 0px 12px;
}

.product-name i:hover {
  color: #ff6d39;
  cursor: pointer;
}

h3 {
  color: #ffffff;
  font-family: "muli";
  margin-top: 84px;
  font-size: 20px;
  font-weight: 500;
}

h2 {
  color: #ffffff;
  font-family: "muli";
  margin-top: 10px;
  font-weight: 800;
  font-size: 29px;
}

h4 {
  display: inline-block;
  color: #ffffff;
  font-family: "muli";
  margin-top: 10px;
  font-weight: bold;
  font-size: 20px;
}

h4.dis {
  display: inline-block;
  color: #ffffff;
  font-family: "muli";
  font-weight: 400;
  font-size: 17px;
  margin-left: 30px;
  text-decoration: line-through #ea3201;
}

h4.dis span {
  text-decoration: line-through #ea3201;
}

.discount {
  display: inline-block;
}

ul {
  list-style-type: none;
}

li {
  display: inline-block;
  margin-right: 25px;
}

ul li {
  color: #ffffff;
  font-family: "muli";
  margin-top: 20px;
  font-weight: 500;
  font-size: 11px;
}

.bg {
  width: 15px;
  height: 15px;
  text-align: center;
  padding: 2px;
  margin-right: 20px;
  transition: 0.3s all ease;
  border-radius: 50%;
}

.bg:hover {
  background-color: #ff6d39;
  border-radius: 50%;
  width: 15px;
  height: 15px;
  cursor: pointer;
}

.yellow {
  content: "";
  width: 13px;
  height: 13px;
  background-color: #fec60f;
  border-radius: 50%;
  border: 2px solid rgba(0, 0, 0, 0);
  transition: 0.3s all ease;
}

.black {
  content: "";
  width: 13px;
  height: 13px;
  background-color: #000000;
  border-radius: 50%;
  border: 2px solid rgba(0, 0, 0, 0);
  transition: 0.3s all ease;
}

.blue {
  content: "";
  width: 13px;
  height: 13px;
  background-color: #02a2ca;
  border-radius: 50%;
  border: 2px solid rgba(0, 0, 0, 0);
  transition: 0.3s all ease;
}

.yellow:hover,
.black:hover,
.blue:hover {
  border: 2px solid #f76b39;
  width: 13px;
  height: 13px;
  border-radius: 50%;
  cursor: pointer;
}

.foot {
  color: #ffffff;
  font-family: "muli";
  margin-top: 20px;
  margin-right: 50px;
  font-weight: 500;
  font-size: 11px;
  float: left;
  transition: 0.3s all ease;
}

.foot i:nth-child(1) {
  margin-left: 0;
  margin-right: 15px;
}

.foot:hover {
  color: #f76b39;
  cursor: pointer;
}

/*shoe slider indicator*/

.left i {
  color: #ffd5c6;
  margin-top: 260px;
  transition: 0.3s all ease;
}

.fa-long-arrow-left {
  margin-left: -275px;
}

.fa-long-arrow-right {
  margin-left: 15px;
}

.left i:hover {
  cursor: pointer;
  color: #2a2f40;
}

/*main card*/

.card {
  display: flex;
  align-items: center;
  background: #252831 url(https://www.dropbox.com/s/fuadz3vmw2nsylm/bg.png?raw=1)
    no-repeat;
  height: 600px;
  width: 800px;
  margin: 0 auto;
  box-shadow: 0px 15px 50px 10px rgba(0, 0, 0, 0.4);
  margin-top: 2%;
}

.left {
  content: "";
  height: 395px;
  width: 330px;
  display: flex;
  align-items: center;
  background-color: #ff6d39;
  margin-left: 93px;
  border-radius: 0% 50% 50% 0%;
  position: absolute;
  z-index: 5;
}

.left img {
  margin-left: -88px;
  margin-top: 60px;
}

.right {
  content: "";
  height: 395px;
  width: 550px;
  background-color: #2a2f40;
  z-index: 3;
  margin-left: 200px;
}

.product-info {
  position: absolute;
  margin-left: 245px;
  height: 394px;
  width: 305px;
  z-index: 10;
}

<style>
            *{
                margin:auto auto;
                padding: auto auto;
            }
            .column{
           margin:auto auto;
           margin-left:400px;
           width:700px;
           color:black;
           font-size:18px;
           font-weight:700px;
            }
            .product{
                margin:auto auto;
                margin-top:10px;
                width:700px;
               color:black;
               font-size:18px;
               font-weight:700px;
            }
            .price{
                margin:auto auto;
                margin-top:10px;
                width:700px;
                color:black;
                font-size:18px;
                font-weight:700px;
            }
            .weight{
                margin:auto auto;
                margin-top:10px;
                width:700px;
                color:black;
               font-size:18px;
               font-weight:700px;
            }
            .amount{
                margin:auto auto;
              margin-top:10px;
               width:700px;
                color:black;
               font-size:18px;
              font-weight:700px;
            }
            .btn{
              margin:auto auto;
              margin-left:250px;
              width:150px;
              color:black;
              font-size:18px;
              font-weight:700px;
            }
        </style>
</head></html>


 
// session_start();
// include("header.php");
// $id=0;
// $price=0;
// $img="";
// $usr=$_SESSION['username'];
// if(isset($_GET["productid"]))
// {
// $pid=$_GET["productid"];
// $prc=$_GET["price"];
// }
// include("connection.php");
// $rs=mysqli_query($cn,"select * from uploadproduct where productid=$pid");
// if($a=mysqli_fetch_array($rs))
// {
//   $prc=$a['price'];
// $img=$a['image'];

// }
// ?>

<h1 align=center>Order Details</h1>
<div class="row">

<form id=frmreg method="post" name="myForm">
  <div class="column">
  <!-- <marquee direction=left> <h3><b>Shetkari Producer Company's Precision Farming</b></h3></marquee> -->
<!-- <img src="images\14.jpg" width=100% height=300px> -->
<!-- <br>
<?php
// echo "<center><img src=\"images/$img\" width=200 height=200></center></div>";
?>
<br>

</div><div class="product">
    <span class="input-group-addon" ><i class="glyphicon glyphicon-grain"></i></span>
    <input ng-model="address" id="productid" type="text" class="form-control" name="productid" placeholder="ProductId" value="<?php echo $pid; ?>" required readonly>

  </div>
<br>
</div><div class="price">
    <span class="input-group-addon"><i class="glyphicon glyphicon-usd"></i></span>
    <input ng-model="address" id="price" type="text" class="form-control" name="price" placeholder="Price" value="<?php echo $prc; ?>" required readonly>
</div>
<br>

  <div class="weight">
    <span class="input-group-addon"><i class="glyphicon glyphicon-shopping-cart"></i></span>
    <select id="qty" name="qty"  onchange="cal()" class="form-control">
<option>--select the quantity--</option>
<option value="1">  1 Kg</option>
<option value="5">5 Kg</option>
<option value="10">10 Kg</option>
<option value="25">25 Kg</option>
<option value="50">50 Kg</option>
<option value="100">100 Kg</option>
</select>

 <script>
function cal()
{
  var p,q,a;
 p=document.getElementById("price").value;
 q=document.getElementById("qty").value;
a=p*q;
document.getElementById("amt").value=a;
}
  </script>
  </div>

<br>
  <div class="amount">
    <span class="input-group-addon"><i class="glyphicon glyphicon-gbp"></i></span>
    <input ng-model="address" id="amt" type="text" class="form-control" name="amt" placeholder="0" required readonly>

  </div>

<br>
 
<br><div class="btn">
       <button type="submit" class="btn btn-primary" id="btnsub" name="btnsub"><a href="payment1.php" style="color:black">Pay Now</a></button>
        <button type="reset" class="btn btn-danger" id="btnres">Reset</button></div>

</form> -->
 -->



</div>
<?php
// include("footer.php");
// if(isset($_POST['btnsub']))
// {
// $usr=$_SESSION['username'];

// $qty=$_POST['qty'];
// $amt=$_POST['amt'];

// include("connection.php");
// $q="insert into buy(Productid,quantity,price) values($pid,'$qty',$prc)";
// mysqli_query($cn,$q);
// mysqli_close($cn);

// }

?> -->

<section class="product">
	<div class="product__photo">
		<div class="photo-container">
			<div class="photo-main">
				<div class="controls">
					<i class="material-icons">share</i>
					<i class="material-icons">favorite_border</i>
				</div>
				<img src="https://res.cloudinary.com/john-mantas/image/upload/v1537291846/codepen/delicious-apples/green-apple-with-slice.png" alt="green apple slice">
			</div>
			<div class="photo-album">
				<ul>
					<li><img src="https://res.cloudinary.com/john-mantas/image/upload/v1537302064/codepen/delicious-apples/green-apple2.png" alt="green apple"></li>
					<li><img src="https://res.cloudinary.com/john-mantas/image/upload/v1537303532/codepen/delicious-apples/half-apple.png" alt="half apple"></li>
					<li><img src="https://res.cloudinary.com/john-mantas/image/upload/v1537303160/codepen/delicious-apples/green-apple-flipped.png" alt="green apple"></li>
					<li><img src="https://res.cloudinary.com/john-mantas/image/upload/v1537303708/codepen/delicious-apples/apple-top.png" alt="apple top"></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="product__info">
		<div class="title">
			<h1>Delicious Apples</h1>
			<span>COD: 45999</span>
		</div>
		<div class="price">
			R$ <span>7.93</span>
		</div>
		<div class="variant">
			<h3>SELECT A COLOR</h3>
			<ul>
				<li><img src="https://res.cloudinary.com/john-mantas/image/upload/v1537302064/codepen/delicious-apples/green-apple2.png" alt="green apple"></li>
				<li><img src="https://res.cloudinary.com/john-mantas/image/upload/v1537302752/codepen/delicious-apples/yellow-apple.png" alt="yellow apple"></li>
				<li><img src="https://res.cloudinary.com/john-mantas/image/upload/v1537302427/codepen/delicious-apples/orange-apple.png" alt="orange apple"></li>
				<li><img src="https://res.cloudinary.com/john-mantas/image/upload/v1537302285/codepen/delicious-apples/red-apple.png" alt="red apple"></li>
			</ul>
		</div>
		<div class="description">
			<h3>BENEFITS</h3>
			<ul>
				<li>Apples are nutricious</li>
				<li>Apples may be good for weight loss</li>
				<li>Apples may be good for bone health</li>
				<li>They're linked to a lowest risk of diabetes</li>
			</ul>
		</div>
		<button class="buy--btn">ADD TO CART</button>
	</div>
</section>

<footer>
	<p>Design from <a href="https://dribbble.com/shots/5216438-Daily-UI-012">dribbble shot</a> of <a href="https://dribbble.com/rodrigorramos">Rodrigo Ramos</a></p>
</footer>