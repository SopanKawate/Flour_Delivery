<html><head>
<style>
            *{
                margin:auto auto;
                padding: auto auto;
            }

            .column{
           margin:auto auto;
           margin-left:400px;
           width:700px;
           color:black;
           font-size:18px;
           font-weight:700px;
            }
            .product{
                margin:auto auto;
                margin-top:10px;
                width:700px;
               color:black;
               font-size:18px;
               font-weight:700px;
            }
            .price{
                margin:auto auto;
                margin-top:10px;
                width:700px;
                color:black;
                font-size:18px;
                font-weight:700px;
            }
            .weight{
                margin:auto auto;
                margin-top:10px;
                width:700px;
                color:black;
               font-size:18px;
               font-weight:700px;
            }
            .amount{
                margin:auto auto;
              margin-top:10px;
               width:700px;
                color:black;
               font-size:18px;
              font-weight:700px;
            }
            .btn{
              margin:auto auto;
              margin-left:250px;
              width:150px;
              color:black;
              font-size:18px;
              font-weight:700px;
            }
        </style>
</head></html>




<?php
session_start();
include("header.php");
$pid=0;
$price=0;
$img="";
$usr=$_SESSION['username'];
if(isset($_GET["productid"]))
{
$pid=$_GET["productid"];
$prc=$_GET["price"];
}
include("connection.php");
$rs=mysqli_query($cn,"select * from uploadproduct where productid=$pid");
if($a=mysqli_fetch_array($rs))
{
  $prc=$a['price'];
$img=$a['image'];

}
?>

<h1 align=center>Order Details</h1>
<div class="row">

<form id=frmreg method="post" name="myForm">
  <div class="column">
  <!-- <marquee direction=left> <h3><b>Shetkari Producer Company's Precision Farming</b></h3></marquee> -->
<!-- <img src="images\14.jpg" width=100% height=300px> -->
<br>
<?php
echo "<center><img src=\"images/$img\" width=200 height=200></center></div>";
?>
<br>

</div><div class="product">
    <span class="input-group-addon" ><i class="glyphicon glyphicon-grain"></i></span>
    <input ng-model="address" id="productid" type="text" class="form-control" name="productid" placeholder="ProductId" value="<?php echo $pid; ?>" required readonly>

  </div>
<br>
</div><div class="price">
    <span class="input-group-addon"><i class="glyphicon glyphicon-usd"></i></span>
    <input ng-model="address" id="price" type="text" class="form-control" name="price" placeholder="Price" value="<?php echo $prc; ?>" required readonly>
</div>
<br>

  <div class="weight">
    <span class="input-group-addon"><i class="glyphicon glyphicon-shopping-cart"></i></span>
    <select id="qty" name="qty"  onchange="cal()" class="form-control">
<option>--select the quantity--</option>
<option value="1">1 Kg</option>
<option value="5">5 Kg</option>
<option value="10">10 Kg</option>
<option value="25">25 Kg</option>
<option value="50">50 Kg</option>
<option value="100">100 Kg</option>
</select>
 <script>
function cal()
{
  var p,q,a;
  p=document.getElementById("price").value;
  q=document.getElementById("qty").value;
  a=p*q;
  document.getElementById("amt").value=a;
}
</script>
  </div>

<br>
  <div class="amount">
    <span class="input-group-addon"><i class="glyphicon glyphicon-gbp"></i></span>
    <input ng-model="address" id="amt" type="text" class="form-control" name="amt" placeholder="0" required readonly>

  </div>

<br>
 
<br><div class="btn">
       <button type="submit" class="btn btn-primary" id="btnsub" name=btnsub>Add to cart</button>
        <button type="reset" class="btn btn-danger" id="btnres">Reset</button></div>

</form>




</div>
<?php
include("footer.php");
if(isset($_POST['btnsub']))
{
$usr=$_SESSION['username'];

$qty=$_POST['qty'];
$amt=$_POST['amt'];

include("connection.php");
$q="insert into cart(username,productid,price,quantity,amount) values('$usr',$pid,$prc,$qty,$amt)";
mysqli_query($cn,$q);
mysqli_close($cn);
echo"<script>alert('Product added to cart');window.location='product.php'</script>";
}

?>