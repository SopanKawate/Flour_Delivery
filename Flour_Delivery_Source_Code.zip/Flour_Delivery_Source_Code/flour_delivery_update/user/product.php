<html>
    <head>
        <style>
            /* *{
                margin:auto auto;
                padding: auto auto;
            } */
            /* .image{
           margin:auto auto;
           margin-top:100px;
           width:600px;
           color:black;
           font-size:18px;
           font-weight:700px;
            } */
            .product{
             /* margin:auto auto; */
              margin-top:100px;
             /* display:flex;
             flex-direction: row;
    justify-content: space-between; */
        width:100%;
        color:black;
        font-size:18px;
        font-weight:700px;
        margin-left:14%;
        /* background-color: bisque; */
            }
            .img-responsive{
                width:200px;
            }
           
        </style>
    </head>
</html>
<?php
include("header.php");
?>
<div class="image">
<div class="row">
<div class="col-sm-12" >
<!-- <marquee direction=left> <h3><b>Shetkari Producer Company's Precision Farming</b></h3></marquee> -->
<!-- <img src="images\flour_back.jpg" width=100% height=300px> -->
</div></div></div>
<h1 align=center>Our Products....</h1>
<div class="product container">
<div class="row">

    <?php
    include("connection.php");
    $rs=mysqli_query($cn,"select*from uploadproduct");
    $i=0;
    while($a=mysqli_fetch_array($rs))
    {

        $nm=$a["productname"];
        $pid=$a["productid"];
        $prc=$a["price"];
        $im=$a["image"];

        //New Code here by Faizan Shaikh
        echo "
        <div class='col-md-4' style='margin-bottom:30px; '>
        <div class='card' style='width: 27rem; border: 1px solid black; box-shadow:0px 0px 10px;padding: 10px'>
        <img src='images/$im' class='card-img-top' style='width:250px; height: 225px;' alt=''>
        <div class='card-body' style=' align-center '>
          <h5 class='card-title'>$nm</h5>
          <p class='card-text'>$prc Rs.</p>
          <a class=\"btn btn-primary\"href=buy.php?productid=$pid&price=$prc >Buy now</a>
          <a class=\"btn btn-danger\"href=cart.php?productid=$pid&price=$prc>Add to cart</a>
        </div>
      </div>
      </div>";
      
        // echo"<div class='col-md-3'>";
        // echo"<div class=\"thumbnail\">";
        // echo"<a href=\"images/$im\"target=\"_blank\">";
        // echo"<img src=\"images/$im\"class=\"img-responsive\">";
        // echo"<b>$nm</b><br><b>Rs:$prc</b></div></a><a class=\"btn btn-primary\"href=buy.php?productid=$pid&price=$prc>Buy now</a>  <a class=\"btn btn-danger\"href=cart.php?productid=$pid&price=$prc>Add to cart</a></div></div>";
        // $i++;
        // if($i==4)
        // {
        //     echo"</div>";
        //     echo"<div class=\"row mb-5\">";
        //     $i=0;
        // }
    }
    
    ?>
    </div>
    </div>
   