<html><head>
<style>
            *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
}
.image{
        margin:auto auto;
        margin-top:10px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}
            .pay{
                margin:auto auto;
                margin-top:10px;
                width:300px;
                height:300px;
               color:black;
               font-size:18px;
               font-weight:700px;
            }
            .payid{
                margin:auto auto;
                margin-top:10px;
                width:500px;
               color:black;
               font-size:18px;
               font-weight:700px;
            }
            .img{
                margin:auto auto;
                margin-top:10px;
                width:500px;
               color:black;
               font-size:18px;
               font-weight:700px;
            }
            .btn{
                margin:auto auto;
                margin-top:30px;
                width:300px;
               font-size:18px;
               font-weight:700px;
               margin-left:300px;
            }
            .field{
        margin:auto auto;
        margin-top:10px;
        width:500px;
        color:black;
        font-size:18px;
        font-weight:700px;
}
           
        </style>
</head></html>







<?php
session_start();
include("header.php");
$am=0;


if(isset($_GET["amount"]))
{
$am=$_GET["amount"];

}
include("connection.php");

?>



<div class="container-fluid">
<div class="image">
<div class="col col-sm-13">
<!-- <marquee direction=left> <h3><b>Shetkari Producer Company's Precision Farming</b></h3></marquee> -->
<!-- <img src="images\28.jpg" width=100% height=300px> -->
</div></div>
<div>
    <form id=frmreg method="post" name="myForm">
   <h1 align=center>Payment</h1>

</div>
<div class="pay">
<div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-usd"></i></span>
    <input ng-model="address" id="Flavour" type="text" class="form-control" name="amount" placeholder="Amount" value="<?php

echo $am; ?>" required readonly>
</div><br>
<div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-shopping-cart"></i></span>
    <select id=wt name=mode class="form-control">
<option>--select payment mode--</option>
<option value="COD">Cash on Delivery</option>
<option value="UPI">Scan UPI</option>


</select>

  </div>

<br>
<h2>Scan QR code to pay</h2>
    <img src="images\p.jpg" width="100%" height="100%">
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<div class="img">
    <h2>Upload the payment screenshot</h2>
<span ckass="input-group-addon"><i class="glyphicon glyphicon-camera"></i><span>
<input ng-model="address" id="address" type="file" class="form-control" name="file1" placeholder="Select Image" required>
  </div>
  <div class="payid">
    <label for="text">Payment ID:</label><br>
    <input type="payid" class="form-control" id="address" placeholder="Enter Your Payment ID" required name="payid">

  </div>
  <div class="field">
    <label><input type="checkbox">Cash On delivery..</label>
  </div>
  <div class="btn">
  <button type="submit" class="btn btn-primary" id="btnsub" name=btnsub><h4>Submit</h4></button>
  

  </div>


  <?php
include("footer.php");
if(isset($_POST['btnsub']))
{
$unm=$_SESSION['username'];

$wt=$_POST['mode'];
$am=$_POST['amount'];
$add=$_POST['num'];

include("connection.php");
$dt=date("d-m-Y");
$q="insert into payment(odt,username,mode,amount) values('$dt','$unm','$wt',$am)";
mysqli_query($cn,$q);


mysqli_close($cn);
echo"<script>alert('Thank You for ordering');window.location='/flour delivery/user/index.php'</script>";
}

?>