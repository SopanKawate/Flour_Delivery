
<style type="text/css">


html{
    background: whitesmoke;
    box-sizing:border-box;
    
}
*{
  box-sizing:inherit;
}
body{
  background: white;
  width:90%;
  max-width: 800px;
  margin:50px auto;
  font-family: Calibri, Arial, sans-serif;
  padding:20px;
  border:2px solid grey;
}
h1, p{
  text-align: center;
}
label{
  display:block;
  margin:1em 0 .2em;
}
/* single-line text, checkbox, and button */
input, select, textarea{
  display:block;
  width:100%;
  padding:.3em;
  font-size:20px;
  background-color:#fbfbfb;
  border:solid 1px #CCC;
  resize:vertical;
}
textarea{
  min-height:180px;
}
select{
  color:indigo;
}
option{
  color:blue;
  background: lavenderBlush;
}
input[type=checkbox]{
  display:inline;
  width:auto;
  color:red;
}

input[type=submit]{
  background:lightcoral;
  margin:1em 0 0;
  color:white;
  border:none;
  border-radius:8px;
  transition:all .3s ease-out;
}

input:focus,
input:hover,
select:focus,
select:hover,
textarea:focus,
textarea:hover{
  background: lavenderBlush;
}

/* hover and focus states */
input[type=submit]:hover,
input[type=submit]:focus{
  background: lightgreen;
  outline:none;
}

@media screen and (min-width:600px) {
  /*  make the form 2 columns */
  form:after{
    content:'';
    display:block;
    clear:both;
  }
  .column{
    width:50%;
    padding:1em;
    float:left;
  }
}










</style>


<body>
<form action="contactus.php" method="post" style="">
  <h1>Contact Us</h1>
  <p>Please take a moment to get in touch, we will get back to you shortly.</p>

  <div class="column">
    <label for="the-name">Your Name</label>
    <input type="text" name="name" id="the-name">

    <label for="the-email">Email Address</label>
    <input type="email" name="email" id="the-email">

    <label for="the-phone">Phone Number</label>
    <input type="tel" name="phone" id="the-phone">

    <!--  -->
  </div>
  <div class="column">
    <label for="the-message">Message</label>
    <textarea name="message" id="the-message"></textarea>
    <label>
  
    </label>
    <input type="submit" value="Send Message">
  </div>
</form>
</body>

<?php 
// print_r($_POST);
include "connection.php";
if(isset($_POST['name'])){
$query="INSERT INTO `contact`(name, email, phone, message)
 VALUES ('".$_POST['name']."','".$_POST['email']."','".$_POST['phone']."','".$_POST['message']."')";

 $fire=mysqli_query($cn,$query);
 if($fire)
 {
  echo "<script>alert('contact added Successfully.');</script>";
  header('location:index.php');
 }
 else{
  echo "error";
 }
}

?>
