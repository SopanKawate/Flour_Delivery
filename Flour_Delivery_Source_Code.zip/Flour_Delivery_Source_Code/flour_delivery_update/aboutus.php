 <?php
include("header.php");
?>

<style type="text/css">
<center>
body{
   /* background-image:url(images/14.jpg); */
   background-position:center;
   background-size:cover;
   font-family:sans-serif;
   margin: auto auto;
   /* background-color:black; */
 
}

*{
  margin: 0;
  padding: 0;
}
    
.feedbackform{
            width:700px;
          
          margin: auto auto;
          color:#FFFFFF;
           padding:10px 0px 10px 0px;
         text-align:center;
         border-radius:15px 15px 0px 0px;
}

.aboutus{
         margin:auto auto;
         background-color:#f3edf5;

         }
  #aboutus{
        width:100%;
        height:50px;
}
.aboutus{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}  
</center>
</style>


<div class="aboutus">
<div class="row">
<div class="col-sm-"12">


</div></div>
<h1 align=center>About us... </h1>
<br>
<p align=justify>
<h4><b>At Flour Delivery, our passion lies in delivering top-quality flour right to your doorstep. With meticulous attention to sourcing the finest ingredients, our flour ensures your baked goods are always exceptional. From traditional wheat to gluten-free alternatives, we cater to every baking need. Our commitment to freshness and purity guarantees a delightful culinary experience every time you use our flour. Partnering with trusted suppliers and employing rigorous quality control measures, we uphold the highest standards from grain to packaging. Join our community of bakers and elevate your creations with Flour Delivery – where excellence is our promise and baking is an art.






</b>
</h4>


<?php
include("footer.php");
?>
