
<footer>
        <div class="footer-container">
            <div class="footer-section about">
                <h2>About Us</h2>
                <p>Flour Drop Delivery System is dedicated to revolutionizing the way you receive your flour. We provide a seamless and efficient delivery service, ensuring that you get the freshest and highest quality flour right to your doorstep. Our mission is to make baking and cooking easier for everyone by offering a reliable and convenient flour delivery solution.</p>
            </div>
            <div class="footer-section links">
                <h2>Our Aim</h2>
                <ul>
                    <li>To provide healthy food Home</li>
                    <li>To provide fresh flour Services</li>
                    <li>to provide price efficient product About</li>
                    <li>Customer Satosfaction is objective Contact</li>
                </ul>
            </div>
            <div class="footer-section social">
                <h2>Follow Us</h2>
                <div class="social-links">
                    <a href="https://www.facebook.com" target="_blank">Facebook</a>
                    <a href="https://www.twitter.com" target="_blank">Twitter</a>
                    <a href="https://www.instagram.com" target="_blank">Instagram</a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            &copy; Flour Delivery Management System. All rights reserved.
        </div>
    </footer>
</body>
</html>