<html>
    <head>
        <style>
            /* *{
                margin:auto auto;
                padding: auto auto;
            } */
            .image{
           /* margin:auto auto; */
           margin-top:100px;
           width:100%;
           color:black;
           font-size:18px;
           font-weight:700px;
        
           

            }
            .product{
                margin:auto auto;
              margin-top:100px;`
        width:100%;
        color:black;
        font-size:18px;
        font-weight:700px;
            }
        </style>
    </head>
</html>
<?php
include("header.php");
?>
<div class="image">
<div class="row">
<div class="col-sm-"12">
<!-- <marquee direction=left> <h3><b></b></h3></marquee> -->
<!-- <img src="images\14.jpg" width=100% height=300px> -->
</div></div></div>
<h1 align=center style="font-family:Times New Roman" >Our Products....</h1>
<div class="product container">
    <div class="row">
    <?php
    include("connection.php");
    $rs=mysqli_query($cn,"select * from uploadproduct");
    $i=0;
    while($a=mysqli_fetch_array($rs))
    {
        $nm=$a["productname"];
        $pid=$a["productid"];
        $prc=$a["price"];
        $im=$a["image"];

        echo "
        <div class='col-md-4' style='margin-bottom:30px;'>
        <div class='card' style='width: 18rem;'>
        <img src='images/$im' class='card-img-top' style='width:250px; height: 225px;' alt=''>
        <div class='card-body'>
          <h5 class='card-title'>$nm</h5>
          
        </div>
      </div>
      </div>";
        // echo"<div class='col-md-3'>";
        // echo"<div class=\"img-rounded\">";
        // echo"<a href=\"images/$im\"target=\"_blank\">";
        // echo"<img src=\"images/$im\"class=\"img-responsive\"width=100% height=80%>";
        // echo"<b>Name: $nm</b> $pid</a></div></div>";

        // $i++;
        // if($i==3)
        // {
        //     echo"</div>";
        //     echo"<div class=\"row\">";
        //     $i=0;
        // }
    }
    ?>
    </div>
    </div>