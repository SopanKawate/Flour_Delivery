<?php
include("header1.php");
$pid=$_GET['Productid'];
include("connection.php");
$q="select * from uploadproduct where Productid='$pid'";
$rs=mysqli_query($cn,$q);
$nm="";
$prc="";
$pid="";
$img="";
if($a=mysqli_fetch_array($rs))
{
$pid=$a['productid'];
$prc=$a['price'];
$img=$a['image'];
}
?>

<h1 align=center>Update Product Details Here</h1>
<div class="row">
<div class="col-sm-4">
<form id=frmreg method="post" name="myForm" enctype="multipart/form-data">
<input type=hidden name="productid" value="<?php echo $pid; ?>">

<br>
<div class="row">
<div class="col-sm-4">
<form id=frmreg method="post" name="myForm" enctype="multipart/form-data">
<input type=text placeholder="productname" name="productname" value="<?php echo $nm; ?>">
<br>
<div class="row">
<div class="col-sm-4">
<form id=frmreg method="post" name="myForm" enctype="multipart/form-data">
<input type=text name="price" value="<?php echo $prc; ?>">

<br>
<div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-camera"></i></span>
    <img src="images/<?php echo $img; ?>" width=200 height=200><br>
    <input ng-model="address" id="address" type="file" class="form-control" name="file1" placeholder="Select image" required>
</div>
<br>
    <button type="submit" class="btn btn-primary" id="btnsub"name=btnsub>Update</button>
    <button type="reset" class="btn btn-danger" id="btnres">Reset</button>

</form>
</div>
</div>

<br>
<div class="col-sm-8">
<h1>Product</h1>
<table class=table>
<thead>
<tr>
<th>Productname</th><th>Productid</th><th>Price</th><th>Image</th><th>Actions</th>
</tr>
</thead>

<tbody>
<?php
include("connection.php");
$q="select * from uploadproduct";
$rs=mysqli_query($cn,$q);
while($a=mysqli_fetch_array($rs))
{
$pid=$a['productid'];
$nm=$a['productname'];
$prc=$a['price'];
$img=$a['image'];
echo "<tr>";
echo "<td>$nm</td><td>$pid</td><td>$prc</td><td><img src=images/$img width=100 height=100></td><td><a class='btn btn-danger' href=del3.php?Productname=$nm>Delete</a> <a class='btn btn-info' href=del3.php?Productname=$nm>Update</a></td>";
echo "</tr>";
}
?>
</tbody>
</table>
</div>
</div>

<?php
include("footer.php");
if(isset($_POST['btnsub']))
{
$pid=$_POST['productid'];
$nm=$_POST['productname'];
$prc=$_POST['price'];
//code for image uploading
$fn=$_FILES['file1']['name'];
$s=$_FILES['file1']['size'];
$tnm=$_FILES['file1']['tmp_name'];
$ptr1=fopen($tnm,"r");
$ptr2=fopen("images/$fn","w");
$data=fread($ptr1,$s);
fwrite($ptr2,$data);
fclose($ptr1);
fclose($ptr2);
//end of image uploading
include("connection.php");
$q="update uploadproduct set Productname='$nm',Price='$prc',Image='$fn' where Productid=$pid";
mysqli_query($cn,$q);
mysqli_close($cn);
echo"<script>alert('Product Updated Successfully');window.location='product.php'</script>";
}
?>