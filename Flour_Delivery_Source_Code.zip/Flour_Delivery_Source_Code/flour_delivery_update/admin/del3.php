<?php
$pid=$_GET['Productid'];
include("../connection.php");
$q="delete from uploadproduct where Productid='$pid'";
mysqli_query($cn,$q);
mysqli_close($cn);
echo"<script>alert('Record deleted');window.location='product.php'</script>";
?>